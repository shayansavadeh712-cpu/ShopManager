package com.moshtarikon.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

class MainActivity : ComponentActivity() {
    private val vm: AdminVm by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val scheme = darkColorScheme(
                primary = Color(0xFF6FA0FF), onPrimary = Color(0xFF06142E),
                primaryContainer = Color(0xFF1D3F85), onPrimaryContainer = Color(0xFFDCE8FF),
                secondary = Color(0xFF9DB7E8), tertiary = Color(0xFF7DE0C2),
                background = Color(0xFF0B0F1A), onBackground = Color(0xFFEAEFFB),
                surface = Color(0xFF121827), onSurface = Color(0xFFEAEFFB),
                surfaceVariant = Color(0xFF1B2336), onSurfaceVariant = Color(0xFFA8B3CC),
                outline = Color(0xFF55607A), outlineVariant = Color(0xFF2A344D),
                error = Color(0xFFFF6B6B), errorContainer = Color(0xFF5A1D1D), onErrorContainer = Color(0xFFFFDAD6)
            )
            MaterialTheme(colorScheme = scheme) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Box(Modifier.fillMaxSize().background(scheme.background)) { Root(vm) }
                }
            }
        }
    }
}
