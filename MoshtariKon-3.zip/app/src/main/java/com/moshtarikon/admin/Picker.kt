package com.moshtarikon.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChevronLeft
import androidx.compose.material.icons.rounded.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.icu.util.Calendar
import android.icu.util.ULocale

private val MONTHS = listOf("فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور", "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند")
private val WEEK = listOf("ش", "ی", "د", "س", "چ", "پ", "ج")

private fun pcal(sec: Long): Calendar =
    Calendar.getInstance(ULocale("fa_IR@calendar=persian")).also { it.timeInMillis = sec * 1000 }

private fun daysIn(y: Int, m: Int): Int {
    val c = pcal(0)
    c.set(Calendar.YEAR, y); c.set(Calendar.MONTH, m); c.set(Calendar.DAY_OF_MONTH, 1)
    return c.getActualMaximum(Calendar.DAY_OF_MONTH)
}

private fun firstOffset(y: Int, m: Int): Int {
    val c = pcal(0)
    c.set(Calendar.YEAR, y); c.set(Calendar.MONTH, m); c.set(Calendar.DAY_OF_MONTH, 1)
    return c.get(Calendar.DAY_OF_WEEK) % 7 // شنبه = 0
}

private fun digits(s: String): String = buildString {
    for (ch in s) when (ch) {
        in '0'..'9' -> append(ch)
        in '۰'..'۹' -> append('0' + (ch - '۰'))
        in '٠'..'٩' -> append('0' + (ch - '٠'))
    }
}

/** انتخاب تاریخ شمسی و ساعت/دقیقه با تقویم؛ خروجی ثانیهٔ یونیکس */
@Composable
fun JalaliPickerDialog(initial: Long, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val start = if (initial > 0) initial else System.currentTimeMillis() / 1000
    val c0 = remember { pcal(start) }
    var y by remember { mutableStateOf(c0.get(Calendar.YEAR)) }
    var m by remember { mutableStateOf(c0.get(Calendar.MONTH)) }
    var d by remember { mutableStateOf(c0.get(Calendar.DAY_OF_MONTH)) }
    var hh by remember { mutableStateOf(c0.get(Calendar.HOUR_OF_DAY).toString()) }
    var mi by remember { mutableStateOf(c0.get(Calendar.MINUTE).toString()) }

    fun prev() { if (m == 0) { m = 11; y -= 1 } else m -= 1 }
    fun next() { if (m == 11) { m = 0; y += 1 } else m += 1 }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تاریخ و ساعت انقضا") },
        text = {
            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { prev() }) { Icon(Icons.Rounded.ChevronRight, null) }
                    Text(
                        MONTHS[m] + " " + fa(y), Modifier.weight(1f), textAlign = TextAlign.Center,
                        fontWeight = FontWeight.Bold, fontSize = 16.sp
                    )
                    IconButton(onClick = { next() }) { Icon(Icons.Rounded.ChevronLeft, null) }
                }
                Row(Modifier.fillMaxWidth()) {
                    WEEK.forEach {
                        Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                val off = firstOffset(y, m)
                val n = daysIn(y, m)
                val rows = (off + n + 6) / 7
                for (r in 0 until rows) {
                    Row(Modifier.fillMaxWidth()) {
                        for (col in 0 until 7) {
                            val day = r * 7 + col - off + 1
                            Box(Modifier.weight(1f).height(38.dp), contentAlignment = Alignment.Center) {
                                if (day in 1..n) {
                                    val sel = day == d
                                    Box(
                                        Modifier.size(34.dp).clip(CircleShape)
                                            .background(if (sel) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent)
                                            .clickable { d = day },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            fa(day), fontSize = 14.sp,
                                            color = if (sel) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = hh, onValueChange = { hh = digits(it).take(2) }, label = { Text("ساعت") },
                        singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    Text(":", fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = mi, onValueChange = { mi = digits(it).take(2) }, label = { Text("دقیقه") },
                        singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                TextButton(onClick = {
                    val c = pcal(System.currentTimeMillis() / 1000)
                    y = c.get(Calendar.YEAR); m = c.get(Calendar.MONTH); d = c.get(Calendar.DAY_OF_MONTH)
                    hh = c.get(Calendar.HOUR_OF_DAY).toString(); mi = c.get(Calendar.MINUTE).toString()
                }) { Text("همین الان") }
            }
        },
        confirmButton = {
            Button(onClick = {
                val c = pcal(0)
                c.set(Calendar.YEAR, y); c.set(Calendar.MONTH, m); c.set(Calendar.DAY_OF_MONTH, 1)
                c.set(Calendar.DAY_OF_MONTH, minOf(d, c.getActualMaximum(Calendar.DAY_OF_MONTH)))
                c.set(Calendar.HOUR_OF_DAY, (hh.toIntOrNull() ?: 0).coerceIn(0, 23))
                c.set(Calendar.MINUTE, (mi.toIntOrNull() ?: 0).coerceIn(0, 59))
                c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
                onConfirm(c.timeInMillis / 1000)
            }) { Text("ثبت") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } }
    )
}
