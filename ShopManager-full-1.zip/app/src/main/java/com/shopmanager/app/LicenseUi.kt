package com.shopmanager.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay

private fun money(v: Long): String = fa(String.format(java.util.Locale.US, "%,d", v)) + " تومان"

@Composable
fun LicenseGate(vm: AppViewModel) {
    val lic = vm.lic
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val ob = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) lic.onResume() }
        owner.lifecycle.addObserver(ob)
        onDispose { owner.lifecycle.removeObserver(ob) }
    }
    LaunchedEffect(Unit) { lic.start() }
    LaunchedEffect(lic.stage) {
        if (lic.stage == Stage.READY) {
            while (true) {
                delay(30 * 60 * 1000L)
                lic.refresh()
            }
        }
    }
    when (lic.stage) {
        Stage.LOADING -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        Stage.LOGIN -> LoginScreen(lic)
        Stage.CODE -> CodeScreen(lic)
        Stage.SHOP -> ShopSetupScreen(lic)
        Stage.PAYWALL -> PaywallScreen(lic)
        Stage.OFFLINE -> OfflineScreen(lic)
        Stage.READY -> Shell(vm)
    }
}

@Composable
private fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp).padding(top = 28.dp, bottom = 40.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        content = content
    )
}

@Composable
private fun Hero(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, sub: String) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.size(76.dp).clip(CircleShape).background(accentBrush()),
        contentAlignment = Alignment.Center
    ) { Icon(icon, null, tint = cs.onPrimary, modifier = Modifier.size(38.dp)) }
    Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
    Text(sub, color = cs.onSurfaceVariant, fontSize = 14.sp, lineHeight = 22.sp)
}

@Composable
private fun ErrorLine(lic: LicenseState) {
    lic.error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
    lic.info?.let { Text(it, color = MaterialTheme.colorScheme.primary, fontSize = 13.sp) }
}

@Composable
fun LoginScreen(lic: LicenseState) {
    var ph by remember { mutableStateOf("") }
    Page {
        Hero(
            Icons.Rounded.Storefront, "ورود به مدیریت فروشگاه",
            "شمارهٔ موبایلت را وارد کن. یک کد تأیید برایت پیامک می‌کنیم." +
                    (if (!lic.trialUsed) "\nهفت روز اول رایگان است." else "")
        )
        Field(ph, { ph = it }, "شمارهٔ موبایل (09...)", number = true)
        ErrorLine(lic)
        ActionButton(
            if (lic.busy) "در حال ارسال..." else "دریافت کد تأیید",
            { lic.sendCode(ph) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Sms,
            enabled = !lic.busy && ph.length >= 10
        )
    }
}

@Composable
fun CodeScreen(lic: LicenseState) {
    var code by remember { mutableStateOf("") }
    var left by remember { mutableStateOf(60) }
    LaunchedEffect(lic.codeSentAt) {
        while (true) {
            left = (60 - (System.currentTimeMillis() - lic.codeSentAt) / 1000).toInt().coerceAtLeast(0)
            if (left == 0) break
            delay(1000)
        }
    }
    Page {
        Hero(Icons.Rounded.Sms, "کد تأیید", "کد ۶ رقمی ارسال‌شده به ${fa(lic.pendingPhone)} را وارد کن.")
        Field(code, { code = it.take(6) }, "کد تأیید", number = true)
        ErrorLine(lic)
        ActionButton(
            if (lic.busy) "در حال بررسی..." else "تأیید و ورود",
            { lic.verify(code) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Check,
            enabled = !lic.busy && code.length == 6
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { lic.backToLogin() }) { Text("تغییر شماره") }
            TextButton(onClick = { lic.sendCode(lic.pendingPhone) }, enabled = left == 0 && !lic.busy) {
                Text(if (left > 0) "ارسال دوباره (${fa(left)})" else "ارسال دوباره")
            }
        }
    }
}

@Composable
fun ShopSetupScreen(lic: LicenseState) {
    val cs = MaterialTheme.colorScheme
    var url by remember { mutableStateOf("") }
    var key by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }
    var cur by remember { mutableStateOf("تومان") }
    Page {
        Hero(
            Icons.Rounded.Link, "اتصال فروشگاه",
            if (!lic.trialUsed) "با ثبت فروشگاه، ${fa(lic.trialDays)} روز استفادهٔ رایگان شروع می‌شود." else "فروشگاه ووکامرس خودت را ثبت کن."
        )
        AppCard {
            Text("ساخت کلید API", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "۱) در داشبورد وردپرس: ووکامرس ← تنظیمات ← پیشرفته ← REST API\n" +
                        "۲) «افزودن کلید» را بزن و دسترسی را «خواندن/نوشتن» انتخاب کن\n" +
                        "۳) Consumer Key و Secret را همین‌جا وارد کن\n" +
                        "سایت باید HTTPS داشته باشد.",
                color = cs.onSurfaceVariant, fontSize = 13.sp, lineHeight = 22.sp
            )
        }
        Field(url, { url = it }, "آدرس سایت (مثلاً mysite.com)")
        Field(key, { key = it }, "Consumer Key (ck_...)")
        Field(secret, { secret = it }, "Consumer Secret (cs_...)")
        Field(cur, { cur = it }, "واحد پول (مثلاً تومان)")
        Text(
            "هر فروشگاه فقط با یک شماره ثبت می‌شود. کلیدها رمزشده روی سرور نگه‌داری می‌شوند.",
            color = cs.onSurfaceVariant, fontSize = 12.sp
        )
        ErrorLine(lic)
        ActionButton(
            if (lic.busy) "در حال بررسی اتصال..." else "ثبت فروشگاه و شروع",
            { lic.registerShop(url, key, secret, cur) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Check,
            enabled = !lic.busy
        )
        TextButton(onClick = { lic.logout() }) { Text("خروج از حساب") }
    }
}

@Composable
fun PlansPanel(lic: LicenseState) {
    val cs = MaterialTheme.colorScheme
    var selected by remember { mutableStateOf(0L) }
    var coupon by remember { mutableStateOf("") }
    var finalPrice by remember { mutableStateOf<Long?>(null) }
    var couponMsg by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) { lic.loadPlans() }
    LaunchedEffect(lic.plans.size) { if (selected == 0L && lic.plans.isNotEmpty()) selected = lic.plans.first().id }
    if (lic.plans.isEmpty()) {
        Text("در حال دریافت پلن‌ها...", color = cs.onSurfaceVariant)
    }
    lic.plans.forEach { p ->
        val on = p.id == selected
        AppCard(onClick = { selected = p.id; finalPrice = null; couponMsg = null }) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.title, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Text("${fa(p.days)} روز", color = cs.onSurfaceVariant, fontSize = 13.sp)
                    if (p.desc.isNotBlank()) Text(p.desc, color = cs.onSurfaceVariant, fontSize = 12.sp)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(money(p.price), fontWeight = FontWeight.Bold, color = cs.primary)
                    if (on) Pill("انتخاب‌شده", Icons.Rounded.Check)
                }
            }
        }
    }
    if (lic.plans.isNotEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Field(coupon, { coupon = it; finalPrice = null; couponMsg = null }, "کد تخفیف (اختیاری)", Modifier.weight(1f))
            ActionButton("اعمال", {
                lic.checkCoupon(selected, coupon) { fin, pct, err ->
                    if (fin != null) { finalPrice = fin; couponMsg = "${fa(pct)}٪ تخفیف اعمال شد" } else { finalPrice = null; couponMsg = err }
                }
            }, kind = BtnKind.TONAL, enabled = coupon.isNotBlank())
        }
        couponMsg?.let { Text(it, fontSize = 13.sp, color = if (finalPrice != null) cs.primary else cs.error) }
        val sel = lic.plans.firstOrNull { it.id == selected }
        ErrorLine(lic)
        ActionButton(
            if (lic.busy) "در حال اتصال به درگاه..." else "پرداخت " + money(finalPrice ?: sel?.price ?: 0L),
            { lic.pay(selected, coupon) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.CreditCard,
            enabled = !lic.busy && sel != null
        )
        if (lic.payingId != 0L) {
            Text(
                "بعد از پرداخت به برنامه برگرد؛ وضعیت خودکار بررسی می‌شود.",
                color = cs.onSurfaceVariant, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth()
            )
        }
    }
    if (lic.support.isNotBlank()) Text(lic.support, color = cs.onSurfaceVariant, fontSize = 12.sp)
}

@Composable
fun PaywallScreen(lic: LicenseState) {
    Page {
        Hero(
            Icons.Rounded.Lock, if (lic.trialUsed && lic.expiresAt > 0) "اشتراک شما تمام شده" else "اشتراک لازم است",
            "برای ادامهٔ استفاده یکی از پلن‌ها را انتخاب کن. اطلاعات فروشگاهت سر جایش می‌ماند."
        )
        PlansPanel(lic)
        TextButton(onClick = { lic.refresh() }) { Text("بررسی دوبارهٔ وضعیت") }
        TextButton(onClick = { lic.logout() }) { Text("خروج از حساب") }
    }
}

@Composable
fun OfflineScreen(lic: LicenseState) {
    Page {
        Hero(
            Icons.Rounded.CloudOff, "اتصال برقرار نیست",
            lic.error ?: "برای بررسی اشتراک باید اینترنت وصل باشد."
        )
        ActionButton("تلاش دوباره", { lic.error = null; lic.refresh() }, Modifier.fillMaxWidth(), icon = Icons.Rounded.Refresh)
        TextButton(onClick = { lic.logout() }) { Text("خروج از حساب") }
    }
}

/** کارت اشتراک در تنظیمات و نوار هشدار */
@Composable
fun SubscriptionCard(lic: LicenseState) {
    val cs = MaterialTheme.colorScheme
    var sheet by remember { mutableStateOf(false) }
    var out by remember { mutableStateOf(false) }
    AppCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(50.dp).clip(CircleShape).background(accentBrush()), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Person, null, tint = cs.onPrimary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(fa(lic.phone), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    (if (lic.isTrial) "دورهٔ رایگان" else "اشتراک") + " · " + fa(lic.daysLeft) + " روز باقی‌مانده",
                    color = if (lic.daysLeft <= 3) cs.error else cs.onSurfaceVariant, fontSize = 13.sp
                )
                if (lic.expiresAt > 0) Text("تا " + fmtDay(lic.expiresAt / 86400), color = cs.onSurfaceVariant, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton("خرید / تمدید اشتراک", { sheet = true }, Modifier.weight(1f), icon = Icons.Rounded.CreditCard)
            ActionButton("خروج", { out = true }, kind = BtnKind.DANGER)
        }
    }
    if (sheet) AppSheet({ sheet = false }, "خرید یا تمدید اشتراک") { PlansPanel(lic) }
    if (out) {
        ConfirmDialog(
            title = "خروج از حساب؟",
            text = "برای ورود دوباره، کد پیامکی لازم است.",
            confirmText = "خروج", danger = true,
            onConfirm = { out = false; lic.logout() },
            onDismiss = { out = false }
        )
    }
}

@Composable
fun SubscriptionBanner(lic: LicenseState, modifier: Modifier = Modifier) {
    var sheet by remember { mutableStateOf(false) }
    if (lic.stage == Stage.READY && lic.daysLeft <= 3) {
        Row(
            modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.errorContainer)
                .clickable { sheet = true }.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                (if (lic.isTrial) "دورهٔ رایگان" else "اشتراک") + ": " + fa(lic.daysLeft) + " روز مانده · تمدید",
                color = MaterialTheme.colorScheme.onErrorContainer, fontSize = 13.sp, fontWeight = FontWeight.Bold
            )
        }
    }
    if (sheet) AppSheet({ sheet = false }, "خرید یا تمدید اشتراک") { PlansPanel(lic) }
}
