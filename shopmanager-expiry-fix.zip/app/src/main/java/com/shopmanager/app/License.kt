package com.shopmanager.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID

/** آدرس سرور اشتراک (افزونهٔ مشتری‌کن روی سایت شما) */
const val LIC_BASE = "https://mahdiabdoli.khazaeestore.com/wp-json/mk/v1"

class LicResp(val code: Int, val body: String) {
    val json: JSONObject? = try { JSONObject(body) } catch (e: Exception) { null }
    val ok: Boolean get() = code in 200..299 && json?.optBoolean("ok", false) == true
    fun err(): String {
        val j = json
        val e = j?.optString("error").orEmpty()
        if (e.isNotBlank()) return e
        val m = j?.optString("message").orEmpty()
        if (m.isNotBlank()) return m
        return "خطای ارتباط با سرور ($code)"
    }
}

suspend fun licCall(
    method: String,
    path: String,
    token: String = "",
    body: JSONObject? = null,
    query: Map<String, String> = emptyMap()
): LicResp = withContext(Dispatchers.IO) {
    // پارامتر زمان: جلوی کش شدن پاسخ‌های GET (مثلاً توسط افزونهٔ کش یا CDN) را می‌گیرد
    val q2 = if (method == "GET") query + ("_" to System.currentTimeMillis().toString()) else query
    val qs = if (q2.isEmpty()) "" else "?" + q2.entries.joinToString("&") {
        URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
    }
    val conn = URL(LIC_BASE + path + qs).openConnection() as HttpURLConnection
    try {
        conn.useCaches = false
        conn.setRequestProperty("Cache-Control", "no-cache")
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.setRequestProperty("Accept", "application/json")
        if (token.isNotEmpty()) {
            conn.setRequestProperty("Authorization", "Bearer $token")
            conn.setRequestProperty("X-MK-Token", token)
        }
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val stream = if (code >= 400) conn.errorStream else conn.inputStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        LicResp(code, text)
    } finally {
        conn.disconnect()
    }
}

data class LicPlan(val id: Long, val title: String, val days: Int, val price: Long, val desc: String)

enum class Stage { LOADING, LOGIN, CODE, SHOP, PAYWALL, OFFLINE, READY }

class LicenseState(app: Application, private val woo: WooState, private val scope: CoroutineScope) {
    private val sp = app.getSharedPreferences("lic", Context.MODE_PRIVATE)
    private val appCtx: Context = app.applicationContext

    var stage by mutableStateOf(Stage.LOADING)
    var phone by mutableStateOf(sp.getString("ph", "") ?: "")
    var pendingPhone by mutableStateOf("")
    var busy by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var info by mutableStateOf<String?>(null)

    var active by mutableStateOf(false)
    var expiresAt by mutableLongStateOf(0L)
    var daysLeft by mutableStateOf(0)
    var remainingSec by mutableLongStateOf(0L)
    var isTrial by mutableStateOf(false)
    var trialUsed by mutableStateOf(false)
    var trialDays by mutableStateOf(7)
    var support by mutableStateOf("")
    val plans = mutableStateListOf<LicPlan>()
    var codeSentAt by mutableLongStateOf(0L)
    var payingId by mutableLongStateOf(sp.getLong("pay", 0L))

    private var token = Vault.dec(sp.getString("tk", "") ?: "")
    private var lastRefresh = 0L
    private var started = false

    private val deviceId: String
        get() {
            var d = sp.getString("did", null)
            if (d == null) {
                d = UUID.randomUUID().toString().replace("-", "")
                sp.edit().putString("did", d).apply()
            }
            return d
        }

    // ── زمان سرور (محافظت در برابر عوض کردن ساعت گوشی)
    private fun note(r: LicResp) {
        val n = r.json?.optLong("now", 0L) ?: 0L
        if (n > 0) sp.edit().putLong("srv", n).putLong("el", SystemClock.elapsedRealtime()).apply()
    }

    private fun serverNow(): Long? {
        val s = sp.getLong("srv", 0L)
        val el = sp.getLong("el", 0L)
        val cur = SystemClock.elapsedRealtime()
        if (s == 0L || cur < el) return null
        return s + (cur - el) / 1000
    }

    private fun readStatus(st: JSONObject) {
        active = st.optBoolean("active", false)
        expiresAt = st.optLong("expires_at", 0L)
        daysLeft = st.optInt("days_left", 0)
        isTrial = st.optBoolean("trial", false)
        trialUsed = st.optBoolean("trial_used", false)
        updateRemaining()
        if (active && remainingSec > 0L) LicenseReminder.schedule(appCtx, remainingSec)
        else LicenseReminder.cancelAll(appCtx)
    }

    // ── قفل دقیق بر اساس ساعت سرور (با تغییر ساعت گوشی دور زده نمی‌شود)
    private fun nowSec(): Long = serverNow() ?: (System.currentTimeMillis() / 1000)

    private fun updateRemaining() {
        if (expiresAt <= 0L) {
            remainingSec = 0L
            return
        }
        val left = (expiresAt - nowSec()).coerceAtLeast(0L)
        remainingSec = left
        daysLeft = ((left + 86399L) / 86400L).toInt()
    }

    /** هر ثانیه از صفحهٔ اصلی صدا زده می‌شود؛ لحظهٔ پایان اشتراک برنامه را قفل می‌کند. */
    fun tick() {
        updateRemaining()
        if (stage == Stage.READY && expiresAt > 0L && remainingSec <= 0L) lockNow()
    }

    private fun lockNow() {
        active = false
        woo.lockOut()
        clearCache()
        LicenseReminder.cancelAll(appCtx)
        stage = Stage.PAYWALL
        scope.launch { loadPlansNow() }
        refresh()
    }

    // ── کش آفلاین کلیدها (حداکثر ۴۸ ساعت)
    private fun saveCache(url: String, ck: String, cs: String, validUntil: Long) {
        val j = JSONObject().put("url", url).put("ck", ck).put("cs", cs).put("vu", validUntil)
        sp.edit().putString("cc", Vault.enc(j.toString())).apply()
    }

    private fun clearCache() {
        sp.edit().remove("cc").apply()
    }

    private fun tryOffline(): Boolean {
        val raw = Vault.dec(sp.getString("cc", "") ?: "")
        if (raw.isBlank()) return false
        return try {
            val j = JSONObject(raw)
            val sn = serverNow() ?: return false
            if (sn >= j.optLong("vu", 0L)) return false
            woo.applyServer(j.optString("url"), j.optString("ck"), j.optString("cs"))
            stage = Stage.READY
            true
        } catch (e: Exception) {
            false
        }
    }

    fun start() {
        if (started) return
        started = true
        if (token.isEmpty()) stage = Stage.LOGIN else refresh()
    }

    fun onResume() {
        if (!started) return
        tick()
        if (payingId != 0L) {
            pollPay()
        } else if (stage == Stage.READY && System.currentTimeMillis() - lastRefresh > 60 * 1000L) {
            refresh()
        }
    }

    // ── ورود
    fun sendCode(ph: String) {
        if (busy) return
        busy = true
        error = null
        scope.launch {
            try {
                val r = licCall("POST", "/otp/send", body = JSONObject().put("phone", ph))
                if (r.ok) {
                    pendingPhone = ph
                    codeSentAt = System.currentTimeMillis()
                    stage = Stage.CODE
                } else error = r.err()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "اتصال به سرور برقرار نشد؛ اینترنت را بررسی کن"
            }
            busy = false
        }
    }

    fun verify(code: String) {
        if (busy) return
        busy = true
        error = null
        scope.launch {
            try {
                val r = licCall(
                    "POST", "/otp/verify",
                    body = JSONObject().put("phone", pendingPhone).put("code", code)
                        .put("device_id", deviceId).put("device_name", Build.MANUFACTURER + " " + Build.MODEL)
                )
                note(r)
                if (r.ok) {
                    token = r.json!!.optString("token")
                    phone = r.json!!.optString("phone", pendingPhone)
                    sp.edit().putString("tk", Vault.enc(token)).putString("ph", phone).apply()
                    r.json!!.optJSONObject("status")?.let { readStatus(it) }
                    stage = Stage.LOADING
                    busy = false
                    refresh()
                    return@launch
                } else error = r.err()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "اتصال به سرور برقرار نشد؛ اینترنت را بررسی کن"
            }
            busy = false
        }
    }

    fun backToLogin() {
        error = null
        stage = Stage.LOGIN
    }

    // ── وضعیت اشتراک و کلیدها
    fun refresh() {
        if (token.isEmpty()) {
            stage = Stage.LOGIN
            return
        }
        lastRefresh = System.currentTimeMillis()
        scope.launch {
            try {
                val me = licCall("GET", "/me", token)
                note(me)
                if (me.code == 401) {
                    wipe()
                    stage = Stage.LOGIN
                    return@launch
                }
                if (!me.ok) {
                    error = me.err()
                    if (!tryOffline()) stage = Stage.OFFLINE
                    return@launch
                }
                val j = me.json!!
                readStatus(j.getJSONObject("status"))
                phone = j.optString("phone", phone)
                val shops = j.optJSONArray("shops")
                val hasShop = shops != null && shops.length() > 0
                if (!hasShop && !trialUsed) {
                    woo.lockOut()
                    stage = Stage.SHOP
                    return@launch
                }
                if (!active) {
                    woo.lockOut()
                    clearCache()
                    loadPlansNow()
                    stage = Stage.PAYWALL
                    return@launch
                }
                if (!hasShop) {
                    stage = Stage.SHOP
                    return@launch
                }
                fetchCredentials()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                if (!tryOffline()) {
                    error = "اتصال به سرور برقرار نشد"
                    stage = Stage.OFFLINE
                }
            }
        }
    }

    private suspend fun fetchCredentials() {
        val r = licCall("GET", "/shop/credentials", token)
        note(r)
        val j = r.json
        if (r.code == 401) {
            wipe()
            stage = Stage.LOGIN
            return
        }
        if (r.code == 402) {
            j?.optJSONObject("status")?.let { readStatus(it) }
            active = false
            woo.lockOut()
            clearCache()
            loadPlansNow()
            stage = Stage.PAYWALL
            return
        }
        if (r.code == 404) {
            stage = Stage.SHOP
            return
        }
        if (!r.ok || j == null) {
            error = r.err()
            if (!tryOffline()) stage = Stage.OFFLINE
            return
        }
        j.optJSONObject("status")?.let { readStatus(it) }
        val url = j.optString("url")
        val ck = j.optString("ck")
        val cs = j.optString("cs")
        saveCache(url, ck, cs, j.optLong("valid_until", 0L))
        woo.applyServer(url, ck, cs)
        stage = Stage.READY
    }

    fun registerShop(url: String, ck: String, cs: String, cur: String) {
        if (busy) return
        val u = WooClient.normalize(url)
        if (u.startsWith("http://")) {
            error = "فقط سایت‌های HTTPS پشتیبانی می‌شوند"
            return
        }
        if (ck.isBlank() || cs.isBlank()) {
            error = "Consumer Key و Secret را وارد کن"
            return
        }
        busy = true
        error = null
        scope.launch {
            try {
                val r = licCall(
                    "POST", "/shop/register", token,
                    JSONObject().put("url", u).put("ck", ck.trim()).put("cs", cs.trim())
                )
                note(r)
                if (r.code == 401) {
                    wipe()
                    stage = Stage.LOGIN
                } else if (r.ok) {
                    woo.changeCurrency(cur)
                    busy = false
                    refresh()
                    return@launch
                } else error = r.err()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "اتصال به سرور برقرار نشد"
            }
            busy = false
        }
    }

    // ── پلن‌ها و پرداخت
    private suspend fun loadPlansNow() {
        try {
            val r = licCall("GET", "/plans")
            if (r.ok) {
                val a = r.json!!.optJSONArray("plans")
                plans.clear()
                if (a != null) for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    plans.add(LicPlan(o.optLong("id"), o.optString("title"), o.optInt("days"), o.optLong("price"), o.optString("description")))
                }
                support = r.json!!.optString("support")
                trialDays = r.json!!.optInt("trial_days", 7)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
        }
    }

    fun loadPlans() {
        scope.launch { loadPlansNow() }
    }

    fun checkCoupon(planId: Long, code: String, onResult: (Long?, Int, String?) -> Unit) {
        scope.launch {
            try {
                val r = licCall("POST", "/coupon/check", token, JSONObject().put("plan_id", planId).put("coupon", code))
                if (r.ok) onResult(r.json!!.optLong("final"), r.json!!.optInt("percent"), null)
                else onResult(null, 0, r.err())
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onResult(null, 0, "اتصال به سرور برقرار نشد")
            }
        }
    }

    fun pay(planId: Long, coupon: String) {
        if (busy) return
        busy = true
        error = null
        scope.launch {
            try {
                val r = licCall("POST", "/pay/start", token, JSONObject().put("plan_id", planId).put("coupon", coupon))
                note(r)
                if (r.ok) {
                    val j = r.json!!
                    if (j.optBoolean("free", false)) {
                        busy = false
                        info = "اشتراک فعال شد"
                        refresh()
                        return@launch
                    }
                    payingId = j.optLong("payment_id")
                    sp.edit().putLong("pay", payingId).apply()
                    val i = Intent(Intent.ACTION_VIEW, Uri.parse(j.optString("pay_url"))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    appCtx.startActivity(i)
                } else error = r.err()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                error = "اتصال به سرور برقرار نشد"
            }
            busy = false
        }
    }

    private fun pollPay() {
        val id = payingId
        if (id == 0L) return
        scope.launch {
            try {
                var tries = 0
                while (tries < 4) {
                    val r = licCall("GET", "/pay/status", token, query = mapOf("id" to id.toString()))
                    note(r)
                    if (r.code == 401) return@launch
                    val ps = r.json?.optString("payment_status").orEmpty()
                    if (r.ok && ps == "paid") {
                        payingId = 0L
                        sp.edit().putLong("pay", 0L).apply()
                        info = "پرداخت موفق بود؛ اشتراک فعال شد"
                        refresh()
                        return@launch
                    }
                    if (r.ok && ps == "failed") {
                        payingId = 0L
                        sp.edit().putLong("pay", 0L).apply()
                        error = "پرداخت انجام نشد یا لغو شد"
                        return@launch
                    }
                    tries++
                    delay(2000)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
            }
        }
    }

    private fun wipe() {
        token = ""
        sp.edit().remove("tk").remove("cc").remove("pay").apply()
        payingId = 0L
        active = false
        LicenseReminder.cancelAll(appCtx)
        woo.disconnect()
    }

    fun logout() {
        val t = token
        scope.launch {
            try {
                if (t.isNotEmpty()) licCall("POST", "/logout", t)
            } catch (e: Exception) {
            }
        }
        wipe()
        error = null
        stage = Stage.LOGIN
    }
}

/** زمان باقی‌مانده: «۲۳ روز و ۰۴:۱۲:۰۹» یا در روز آخر «۰۴:۱۲:۰۹» */
fun fmtRemain(sec: Long): String {
    val s = sec.coerceAtLeast(0L)
    val d = s / 86400L
    val h = (s % 86400L) / 3600L
    val m = (s % 3600L) / 60L
    val x = s % 60L
    val clock = fa(String.format(java.util.Locale.US, "%02d:%02d:%02d", h, m, x))
    return if (d > 0L) fa(d.toInt()) + " روز و " + clock else clock
}

/** تاریخ شمسی و ساعت دقیق پایان اشتراک */
fun fmtExpiry(sec: Long): String {
    if (sec <= 0L) return "—"
    val z = java.time.Instant.ofEpochSecond(sec).atZone(java.time.ZoneId.systemDefault())
    return fmtDay(z.toLocalDate().toEpochDay()) + " ساعت " + fa(String.format(java.util.Locale.US, "%02d:%02d", z.hour, z.minute))
}
