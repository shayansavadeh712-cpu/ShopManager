package com.moshtarikon.admin

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** آدرس سرور اشتراک (افزونهٔ مشتری‌کن) */
const val API_BASE = "https://mahdiabdoli.khazaeestore.com/wp-json/mk/v1"

class ApiResp(val code: Int, val body: String) {
    val json: JSONObject? = try { JSONObject(body) } catch (e: Exception) { null }
    val ok: Boolean get() = code in 200..299 && json?.optBoolean("ok", false) == true
    fun err(): String {
        val e = json?.optString("error").orEmpty()
        if (e.isNotBlank()) return e
        val m = json?.optString("message").orEmpty()
        if (m.isNotBlank()) return m
        return "خطای ارتباط با سرور ($code)"
    }
}

object Api {
    suspend fun call(
        method: String,
        path: String,
        token: String = "",
        body: JSONObject? = null,
        query: Map<String, String> = emptyMap()
    ): ApiResp = withContext(Dispatchers.IO) {
        val qs = if (query.isEmpty()) "" else "?" + query.entries.joinToString("&") {
            URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8")
        }
        val conn = URL(API_BASE + path + qs).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = method
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("Accept", "application/json")
            if (token.isNotEmpty()) {
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.setRequestProperty("X-MK-Token", token)
            }
            if (body != null) {
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code >= 400) conn.errorStream else conn.inputStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            ApiResp(code, text)
        } finally {
            conn.disconnect()
        }
    }
}

object Vault {
    private const val ALIAS = "mk_admin_vault"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return kg.generateKey()
    }

    fun enc(plain: String): String {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
        return Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
    }

    fun dec(s: String): String {
        if (s.isEmpty()) return ""
        return try {
            val b = Base64.decode(s, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(0, 12)))
            String(c.doFinal(b, 12, b.size - 12), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}

fun fa(s: String): String {
    val sb = StringBuilder()
    for (ch in s) sb.append(if (ch in '0'..'9') ('۰' + (ch - '0')) else ch)
    return sb.toString()
}

fun fa(n: Long): String = fa(n.toString())
fun fa(n: Int): String = fa(n.toString())

fun money(v: Long): String = fa(String.format(java.util.Locale.US, "%,d", v)) + " تومان"

/** تاریخ شمسی + ساعت از ثانیهٔ یونیکس */
fun dateFa(sec: Long, withTime: Boolean = true): String {
    if (sec <= 0) return "—"
    val c = android.icu.util.Calendar.getInstance(android.icu.util.ULocale("fa_IR@calendar=persian"))
    c.timeInMillis = sec * 1000
    val d = "${c.get(android.icu.util.Calendar.YEAR)}/${c.get(android.icu.util.Calendar.MONTH) + 1}/${c.get(android.icu.util.Calendar.DAY_OF_MONTH)}"
    val t = String.format(java.util.Locale.US, "%02d:%02d", c.get(android.icu.util.Calendar.HOUR_OF_DAY), c.get(android.icu.util.Calendar.MINUTE))
    return fa(if (withTime) "$d  $t" else d)
}
