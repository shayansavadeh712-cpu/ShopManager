package com.moshtarikon.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.delay
import org.json.JSONObject

// ───────────────────────── ابزارهای UI ─────────────────────────

@Composable
fun TField(
    value: String,
    onChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    number: Boolean = false,
    password: Boolean = false,
    singleLine: Boolean = true
) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else if (password) KeyboardType.Password else KeyboardType.Text),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.fillMaxWidth()
    )
}

@Composable
fun Card2(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(MaterialTheme.colorScheme.surfaceVariant)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun Chip(text: String, color: Color = MaterialTheme.colorScheme.primary) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = .18f)).padding(horizontal = 10.dp, vertical = 3.dp)) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun statusChip(st: JSONObject?) {
    if (st == null) return
    val cs = MaterialTheme.colorScheme
    when {
        st.optBoolean("banned") -> Chip("مسدود", cs.error)
        st.optBoolean("active") && st.optBoolean("trial") -> Chip("رایگان", cs.tertiary)
        st.optBoolean("active") -> Chip("فعال", Color(0xFF4ADE80))
        else -> Chip("منقضی", cs.outline)
    }
}

@Composable
fun FilterRow(options: List<Pair<String, String>>, selected: String, onSel: (String) -> Unit) {
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (k, l) ->
            FilterChip(selected = selected == k, onClick = { onSel(k) }, label = { Text(l) })
        }
    }
}

@Composable
fun FullDialog(onClose: () -> Unit, title: String, content: @Composable ColumnScope.() -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false, decorFitsSystemWindows = false)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            Column(Modifier.fillMaxSize().statusBarsPadding().imePadding()) {
                Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "بستن") }
                    Text(title, Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
                }
                Column(
                    Modifier.weight(1f).fillMaxWidth().padding(horizontal = 16.dp).verticalScroll(rememberScrollState())
                        .navigationBarsPadding().padding(bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    content = content
                )
            }
        }
    }
}

// ───────────────────────── ریشه ─────────────────────────

@Composable
fun Root(vm: AdminVm) {
    if (!vm.loggedIn) LoginScreen(vm) else MainScaffold(vm)
}

@Composable
fun LoginScreen(vm: AdminVm) {
    var user by remember { mutableStateOf(vm.lastUser) }
    var pass by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().imePadding().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically)
    ) {
        Text("مدیریت مشتری‌کن", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("با نام کاربری و رمز مدیر وارد شو (در تنظیمات افزونه تعریف شده).", color = MaterialTheme.colorScheme.onSurfaceVariant)
        TField(user, { user = it }, "نام کاربری")
        TField(pass, { pass = it }, "رمز", password = true)
        vm.msg?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Button(
            onClick = { vm.msg = null; vm.login(user, pass) },
            enabled = !vm.busy && user.isNotBlank() && pass.isNotBlank(),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (vm.busy) "در حال ورود..." else "ورود") }
    }
}

private val tabs = listOf(
    Icons.Rounded.Dashboard to "آمار",
    Icons.Rounded.People to "مشتری‌ها",
    Icons.Rounded.Sell to "پلن‌ها",
    Icons.Rounded.Payments to "پرداخت‌ها",
    Icons.Rounded.LocalOffer to "تخفیف"
)

@Composable
fun MainScaffold(vm: AdminVm) {
    val snack = remember { SnackbarHostState() }
    LaunchedEffect(vm.msg) {
        vm.msg?.let { snack.showSnackbar(it); vm.msg = null }
    }
    LaunchedEffect(vm.tab) {
        when (vm.tab) {
            0 -> vm.loadStats()
            1 -> vm.loadCustomers(true)
            2 -> vm.loadPlans()
            3 -> vm.loadPayments(true)
            4 -> vm.loadCoupons()
        }
    }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                tabs.forEachIndexed { i, (ic, label) ->
                    NavigationBarItem(
                        selected = vm.tab == i, onClick = { vm.tab = i },
                        icon = { Icon(ic, label) }, label = { Text(label, fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            when (vm.tab) {
                0 -> DashboardScreen(vm)
                1 -> CustomersScreen(vm)
                2 -> PlansScreen(vm)
                3 -> PaymentsScreen(vm)
                else -> CouponsScreen(vm)
            }
        }
    }
    vm.detail?.let { CustomerDialog(vm, it) }
}

// ───────────────────────── آمار ─────────────────────────

@Composable
fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Card2(modifier) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun DashboardScreen(vm: AdminVm) {
    val s = vm.stats
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("آمار", Modifier.weight(1f), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                IconButton(onClick = { vm.loadStats() }) { Icon(Icons.Rounded.Refresh, "تازه‌سازی") }
                IconButton(onClick = { vm.logout() }) { Icon(Icons.Rounded.Logout, "خروج") }
            }
        }
        if (s == null) {
            item { Text("در حال دریافت...", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        } else {
            if (s.optBoolean("sandbox")) item {
                Card2 { Text("درگاه در حالت آزمایشی (Sandbox) است؛ پرداخت‌ها واقعی نیستند.", color = MaterialTheme.colorScheme.error) }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatBox("کل کاربران", fa(s.optInt("accounts")), Modifier.weight(1f))
                    StatBox("فعال", fa(s.optInt("active")), Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatBox("رایگان فعال", fa(s.optInt("trial_active")), Modifier.weight(1f))
                    StatBox("پولی فعال", fa(s.optInt("paid_active")), Modifier.weight(1f))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    StatBox("منقضی", fa(s.optInt("expired")), Modifier.weight(1f))
                    StatBox("ثبت‌نام امروز", fa(s.optInt("new_today")), Modifier.weight(1f))
                }
            }
            item { StatBox("درآمد امروز", money(s.optLong("revenue_today")), Modifier.fillMaxWidth()) }
            item { StatBox("درآمد ۳۰ روز اخیر", money(s.optLong("revenue_month")), Modifier.fillMaxWidth()) }
            item { StatBox("درآمد کل", money(s.optLong("revenue_total")), Modifier.fillMaxWidth()) }
        }
    }
}

// ───────────────────────── مشتری‌ها ─────────────────────────

@Composable
fun CustomersScreen(vm: AdminVm) {
    var q by remember { mutableStateOf(vm.custQuery) }
    LaunchedEffect(q) {
        if (q != vm.custQuery) {
            delay(450)
            vm.custQuery = q
            vm.loadCustomers(true)
        }
    }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("مشتری‌ها (${fa(vm.custTotal)})", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold) }
        item { TField(q, { q = it }, "جستجوی شماره یا آدرس سایت") }
        item {
            FilterRow(
                listOf("" to "همه", "active" to "فعال", "trial" to "رایگان", "paid" to "پولی", "expired" to "منقضی", "banned" to "مسدود"),
                vm.custFilter
            ) { vm.custFilter = it; vm.loadCustomers(true) }
        }
        items(vm.customers, key = { it.optLong("id") }) { c ->
            val st = c.optJSONObject("status")
            Card2(onClick = { vm.openCustomer(c.optLong("id")) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(fa(c.optString("phone")), Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    statusChip(st)
                }
                val hosts = c.optString("hosts")
                if (hosts.isNotBlank()) Text(hosts, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                Text(
                    "انقضا: " + dateFa(st?.optLong("expires_at") ?: 0L, false) + " · " + fa(st?.optInt("days_left") ?: 0) + " روز مانده",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp
                )
            }
        }
        if (vm.customers.isEmpty() && !vm.busy) item { Text("مشتری‌ای پیدا نشد", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (vm.custHasMore) item { OutlinedButton(onClick = { vm.loadCustomers(false) }, modifier = Modifier.fillMaxWidth()) { Text("نمایش بیشتر") } }
    }
}

@Composable
fun CustomerDialog(vm: AdminVm, d: JSONObject) {
    val id = d.optLong("id")
    val st = d.optJSONObject("status")
    var days by remember(id) { mutableStateOf("") }
    var note by remember(id, d.optString("note")) { mutableStateOf(d.optString("note")) }
    var confirmBan by remember { mutableStateOf(false) }
    var showPicker by remember { mutableStateOf(false) }
    val banned = st?.optBoolean("banned") == true
    if (showPicker) JalaliPickerDialog(
        initial = st?.optLong("expires_at") ?: 0L,
        onDismiss = { showPicker = false },
        onConfirm = { showPicker = false; vm.setUntil(id, it) }
    )
    FullDialog({ vm.detail = null }, fa(d.optString("phone"))) {
        Card2 {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("وضعیت", Modifier.weight(1f), fontWeight = FontWeight.Bold)
                statusChip(st)
            }
            Spacer(Modifier.height(6.dp))
            Text("انقضا: " + dateFa(st?.optLong("expires_at") ?: 0L), fontSize = 14.sp)
            Text("باقی‌مانده: " + fa(st?.optInt("days_left") ?: 0) + " روز", fontSize = 14.sp)
            Text("ثبت‌نام: " + dateFa(d.optLong("created_at")), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Card2 {
            Text("تمدید / هدیه", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { vm.grant(id, 7, null) }) { Text("+۷ روز") }
                OutlinedButton(onClick = { vm.grant(id, 30, null) }) { Text("+۳۰ روز") }
                OutlinedButton(onClick = { vm.grant(id, 365, null) }) { Text("+۳۶۵") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { showPicker = true }, modifier = Modifier.fillMaxWidth()) { Text("تعیین تاریخ و ساعت دقیق انقضا (تقویم)") }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                TField(days, { days = it }, "تعداد روز (منفی = کم کردن)", Modifier.weight(1f))
                Button(onClick = {
                    val n = days.replace("−", "-").trim().toIntOrNull()
                    if (n == null || n == 0) vm.msg = "تعداد روز معتبر نیست" else { vm.grant(id, n, null); days = "" }
                }) { Text("اعمال") }
            }
        }
        Card2 {
            Text("یادداشت", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            TField(note, { note = it }, "یادداشت (فقط برای خودت)")
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { vm.saveNote(id, note) }) { Text("ذخیرهٔ یادداشت") }
        }
        Card2 {
            Text("فروشگاه‌ها", fontWeight = FontWeight.Bold)
            val shops = d.optJSONArray("shops")
            if (shops == null || shops.length() == 0) Text("فروشگاهی ثبت نشده", color = MaterialTheme.colorScheme.onSurfaceVariant)
            else for (i in 0 until shops.length()) {
                val s = shops.getJSONObject(i)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(s.optString("host"), fontSize = 14.sp)
                        Text(dateFa(s.optLong("created_at"), false), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { vm.removeShop(id, s.optLong("id")) }) { Icon(Icons.Rounded.Delete, "حذف", tint = MaterialTheme.colorScheme.error) }
                }
            }
            Text("حذف فروشگاه، آن را برای ثبت با شمارهٔ دیگر آزاد می‌کند.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Card2 {
            Text("دستگاه‌ها", fontWeight = FontWeight.Bold)
            val devs = d.optJSONArray("devices")
            if (devs == null || devs.length() == 0) Text("دستگاهی نیست", color = MaterialTheme.colorScheme.onSurfaceVariant)
            else for (i in 0 until devs.length()) {
                val x = devs.getJSONObject(i)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(x.optString("label").ifBlank { "دستگاه" }, fontSize = 14.sp)
                        Text("آخرین استفاده: " + dateFa(x.optLong("last_seen")) + " · " + x.optString("ip"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { vm.removeDevice(id, x.optLong("id")) }) { Icon(Icons.Rounded.Delete, "حذف", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
        Card2 {
            Text("پرداخت‌ها", fontWeight = FontWeight.Bold)
            val ps = d.optJSONArray("payments")
            if (ps == null || ps.length() == 0) Text("پرداختی نیست", color = MaterialTheme.colorScheme.onSurfaceVariant)
            else for (i in 0 until ps.length()) {
                val p = ps.getJSONObject(i)
                Text(
                    money(p.optLong("amount")) + " · " + payFa(p.optString("status")) + " · " + dateFa(p.optLong("created_at"), false) +
                            (if (p.optString("ref_id").isNotBlank()) " · پیگیری " + fa(p.optString("ref_id")) else ""),
                    fontSize = 12.sp
                )
            }
        }
        Button(
            onClick = { confirmBan = true },
            colors = if (banned) ButtonDefaults.buttonColors() else ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (banned) "رفع مسدودی" else "مسدود کردن حساب") }
    }
    if (confirmBan) {
        AlertDialog(
            onDismissRequest = { confirmBan = false },
            title = { Text(if (banned) "رفع مسدودی؟" else "مسدود کردن؟") },
            text = { Text(if (banned) "کاربر دوباره می‌تواند وارد شود." else "همهٔ دستگاه‌های کاربر خارج می‌شوند و دسترسی قطع می‌شود.") },
            confirmButton = { TextButton(onClick = { confirmBan = false; vm.ban(id, !banned) }) { Text("تأیید") } },
            dismissButton = { TextButton(onClick = { confirmBan = false }) { Text("انصراف") } }
        )
    }
}

fun payFa(s: String) = when (s) { "paid" -> "موفق"; "failed" -> "ناموفق"; "pending" -> "در انتظار"; else -> s }

// ───────────────────────── پلن‌ها ─────────────────────────

@Composable
fun PlansScreen(vm: AdminVm) {
    var edit by remember { mutableStateOf<JSONObject?>(null) }
    var delId by remember { mutableStateOf(0L) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("پلن‌ها", Modifier.weight(1f), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Button(onClick = { edit = JSONObject().put("id", 0).put("active", true).put("days", 30).put("price", 0) }) {
                    Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("پلن جدید")
                }
            }
        }
        items(vm.plans, key = { it.optLong("id") }) { p ->
            Card2(onClick = { edit = p }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(p.optString("title"), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                        Text(fa(p.optInt("days")) + " روز · " + money(p.optLong("price")), fontSize = 13.sp)
                        if (p.optString("description").isNotBlank()) Text(p.optString("description"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (!p.optBoolean("active")) Chip("غیرفعال", MaterialTheme.colorScheme.outline)
                    IconButton(onClick = { delId = p.optLong("id") }) { Icon(Icons.Rounded.Delete, "حذف", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
        item { Text("قیمت‌ها به تومان است. پلن‌های غیرفعال به کاربران نشان داده نمی‌شوند.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    edit?.let { p ->
        var title by remember(p) { mutableStateOf(p.optString("title")) }
        var d by remember(p) { mutableStateOf(p.optInt("days", 30).toString()) }
        var price by remember(p) { mutableStateOf(p.optLong("price").toString()) }
        var desc by remember(p) { mutableStateOf(p.optString("description")) }
        var sort by remember(p) { mutableStateOf(p.optInt("sort").toString()) }
        var active by remember(p) { mutableStateOf(p.optBoolean("active", true)) }
        AlertDialog(
            onDismissRequest = { edit = null },
            title = { Text(if (p.optLong("id") == 0L) "پلن جدید" else "ویرایش پلن") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TField(title, { title = it }, "عنوان (مثلاً یک ماهه)")
                    TField(d, { d = it }, "مدت (روز)", number = true)
                    TField(price, { price = it }, "قیمت (تومان)", number = true)
                    TField(desc, { desc = it }, "توضیح کوتاه")
                    TField(sort, { sort = it }, "ترتیب نمایش", number = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("فعال", Modifier.weight(1f)); Switch(active, { active = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val days = d.toIntOrNull()
                    if (title.isBlank() || days == null || days < 1) { vm.msg = "عنوان و مدت را درست وارد کن" }
                    else {
                        val b = JSONObject().put("id", p.optLong("id")).put("title", title).put("days", days)
                            .put("price", price.toLongOrNull() ?: 0L).put("description", desc)
                            .put("sort", sort.toIntOrNull() ?: 0).put("active", active)
                        vm.savePlan(b) { edit = null }
                    }
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { edit = null }) { Text("انصراف") } }
        )
    }
    if (delId != 0L) {
        AlertDialog(
            onDismissRequest = { delId = 0L },
            title = { Text("حذف پلن؟") },
            text = { Text("اگر پرداختی با این پلن ثبت شده باشد فقط غیرفعال می‌شود.") },
            confirmButton = { TextButton(onClick = { vm.deletePlan(delId); delId = 0L }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { delId = 0L }) { Text("انصراف") } }
        )
    }
}

// ───────────────────────── پرداخت‌ها ─────────────────────────

@Composable
fun PaymentsScreen(vm: AdminVm) {
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("پرداخت‌ها", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold) }
        item {
            FilterRow(listOf("" to "همه", "paid" to "موفق", "failed" to "ناموفق", "pending" to "در انتظار"), vm.payFilter) {
                vm.payFilter = it; vm.loadPayments(true)
            }
        }
        items(vm.payments, key = { it.optLong("id") }) { p ->
            Card2 {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(money(p.optLong("amount")), Modifier.weight(1f), fontWeight = FontWeight.Bold)
                    val st = p.optString("status")
                    Chip(payFa(st), if (st == "paid") Color(0xFF4ADE80) else if (st == "failed") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.outline)
                }
                Text(fa(p.optString("phone")) + " · " + p.optString("plan_title"), fontSize = 13.sp)
                Text(
                    dateFa(if (p.optLong("paid_at") > 0) p.optLong("paid_at") else p.optLong("created_at")) +
                            (if (p.optString("coupon").isNotBlank()) " · کد " + p.optString("coupon") else "") +
                            (if (p.optString("ref_id").isNotBlank()) " · پیگیری " + fa(p.optString("ref_id")) else ""),
                    fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (vm.payments.isEmpty() && !vm.busy) item { Text("پرداختی ثبت نشده", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        if (vm.payMore) item { OutlinedButton(onClick = { vm.loadPayments(false) }, modifier = Modifier.fillMaxWidth()) { Text("نمایش بیشتر") } }
    }
}

// ───────────────────────── کد تخفیف ─────────────────────────

@Composable
fun CouponsScreen(vm: AdminVm) {
    var edit by remember { mutableStateOf<JSONObject?>(null) }
    var delId by remember { mutableStateOf(0L) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("کد تخفیف", Modifier.weight(1f), fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                Button(onClick = { edit = JSONObject().put("id", 0).put("percent", 10).put("active", true) }) {
                    Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("کد جدید")
                }
            }
        }
        items(vm.coupons, key = { it.optLong("id") }) { c ->
            Card2(onClick = { edit = c }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(c.optString("code"), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                        Text(
                            fa(c.optInt("percent")) + "٪ تخفیف · استفاده: " + fa(c.optInt("used")) +
                                    (if (c.optInt("max_uses") > 0) " از " + fa(c.optInt("max_uses")) else "") +
                                    (if (c.optLong("expires_at") > 0) " · تا " + dateFa(c.optLong("expires_at"), false) else ""),
                            fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    if (c.optInt("active") == 0) Chip("غیرفعال", MaterialTheme.colorScheme.outline)
                    IconButton(onClick = { delId = c.optLong("id") }) { Icon(Icons.Rounded.Delete, "حذف", tint = MaterialTheme.colorScheme.error) }
                }
            }
        }
        if (vm.coupons.isEmpty() && !vm.busy) item { Text("کدی ساخته نشده", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
    edit?.let { c ->
        var code by remember(c) { mutableStateOf(c.optString("code")) }
        var pct by remember(c) { mutableStateOf(c.optInt("percent", 10).toString()) }
        var max by remember(c) { mutableStateOf(c.optInt("max_uses").toString()) }
        var daysValid by remember(c) { mutableStateOf("0") }
        var active by remember(c) { mutableStateOf(c.optInt("active", 1) != 0) }
        AlertDialog(
            onDismissRequest = { edit = null },
            title = { Text(if (c.optLong("id") == 0L) "کد جدید" else "ویرایش کد") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    TField(code, { code = it.uppercase() }, "کد (حروف انگلیسی/عدد)")
                    TField(pct, { pct = it }, "درصد تخفیف (۱ تا ۱۰۰)", number = true)
                    TField(max, { max = it }, "حداکثر دفعات استفاده (۰ = نامحدود)", number = true)
                    TField(daysValid, { daysValid = it }, if (c.optLong("expires_at") > 0) "اعتبار از الان (روز) — فعلی تا " + dateFa(c.optLong("expires_at"), false) else "اعتبار از الان (روز، ۰ = بدون انقضا)", number = true)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("فعال", Modifier.weight(1f)); Switch(active, { active = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val p = pct.toIntOrNull()
                    if (code.length < 3 || p == null || p < 1 || p > 100) vm.msg = "کد و درصد را درست وارد کن"
                    else {
                        val dv = daysValid.toLongOrNull() ?: 0L
                        val exp = if (dv > 0) System.currentTimeMillis() / 1000 + dv * 86400 else if (daysValid == "0" && c.optLong("expires_at") > 0 && dv == 0L) c.optLong("expires_at") else 0L
                        val b = JSONObject().put("id", c.optLong("id")).put("code", code).put("percent", p)
                            .put("max_uses", max.toIntOrNull() ?: 0).put("expires_at", exp).put("active", active)
                        vm.saveCoupon(b) { edit = null }
                    }
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { edit = null }) { Text("انصراف") } }
        )
    }
    if (delId != 0L) {
        AlertDialog(
            onDismissRequest = { delId = 0L },
            title = { Text("حذف کد؟") },
            confirmButton = { TextButton(onClick = { vm.deleteCoupon(delId); delId = 0L }) { Text("حذف") } },
            dismissButton = { TextButton(onClick = { delId = 0L }) { Text("انصراف") } }
        )
    }
}
