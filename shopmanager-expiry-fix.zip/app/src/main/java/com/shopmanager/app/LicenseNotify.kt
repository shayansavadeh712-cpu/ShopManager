package com.shopmanager.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** یادآوری پایان اشتراک: ۳ روز، ۱ روز، ۱ ساعت قبل و لحظهٔ پایان. */
object LicenseReminder {
    private val offsets = longArrayOf(3 * 86400L, 86400L, 3600L, 0L)

    private fun pi(ctx: Context, step: Int): PendingIntent {
        val i = Intent(ctx, LicenseReceiver::class.java).putExtra("step", step)
        return PendingIntent.getBroadcast(
            ctx, 9100 + step, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    fun cancelAll(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            for (s in offsets.indices) am.cancel(pi(ctx, s))
        } catch (e: Exception) {
        }
    }

    /** secondsLeft: زمان باقی‌مانده بر اساس ساعت سرور */
    fun schedule(ctx: Context, secondsLeft: Long) {
        cancelAll(ctx)
        if (secondsLeft <= 0L) return
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val now = System.currentTimeMillis()
            for (s in offsets.indices) {
                val fireIn = secondsLeft - offsets[s]
                if (fireIn < 5L) continue
                val at = now + fireIn * 1000L
                if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, s))
                } else {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(ctx, s))
                }
            }
        } catch (e: Exception) {
        }
    }
}

class LicenseReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val step = intent.getIntExtra("step", -1)
        val msg: Pair<String, String> = when (step) {
            0 -> "اشتراک ۳ روز دیگر تمام می‌شود" to "برای اینکه برنامه قفل نشود، از همین حالا تمدید کن."
            1 -> "اشتراک فردا تمام می‌شود" to "کمتر از ۲۴ ساعت مانده؛ اشتراک را تمدید کن."
            2 -> "کمتر از یک ساعت تا پایان اشتراک" to "برای ادامهٔ کار همین حالا تمدید کن."
            3 -> "اشتراک تمام شد" to "برای استفاده از برنامه اشتراک را تمدید کنید."
            else -> return
        }
        Notifier.notify(context, "lic", 7000 + step, msg.first, msg.second)
    }
}
